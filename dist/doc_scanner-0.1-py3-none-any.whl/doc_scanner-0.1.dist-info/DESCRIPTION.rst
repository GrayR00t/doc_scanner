# doc_scanner
Python pip package to scan document. Like cam scanner in android phone. 


